#include "Resource.hpp"

Resource::Resource(){
    this->resource_name = "";
    this->resource_type = "";
    this->x_coordinate = 0.0f;
    this->y_coordinate = 0.0f;
    this->occupied = 0;
}

Resource::Resource(std::string name, std::string type, float x, float y, bool occu){
    this->resource_name = name;
    this->resource_type = type;
    this->x_coordinate = x;
    this->y_coordinate = y;
    this->occupied = occu;
}