#ifndef RESOURCE_HPP
#define RESOURCE_HPP
#include<bits/stdc++.h>


class Resource{
public:
    std::string resource_name;
    std::string resource_type;
    float x_coordinate, y_coordinate;
    bool occupied;      // 0 for empty so far, 1 for occupied

    Resource();
    Resource(std::string name, std::string type, float x, float y, bool occu);

};

#endif // RESOURCE_HPP