--How to Compile
    In "placement/src", enter the following command:
    $ make
    will generate an executable file "legalizer" in the "placement/bin/".

    If you want to remove all *.o ,*.txt and executable file, enter the following command:
    $ make clean

--How to Run
    Usage:
    In "placement/src", enter the following command:
    $ ../bin/legalizer ../public_cases/testcase<X>/<txt file> ../output/<out file>

    E.g.
[fpga-112062576@MakLab:~/placement/src]$ ../bin/legalizer ../public_cases/testcase4/architecture.txt ../public_cases/testcase4/instance.txt ../public_cases/testcase4/netlist.txt ../output/output4.txt
    
../bin/legalizer ../public_cases/testcase3/architecture.txt ../public_cases/testcase3/instance.txt ../public_cases/testcase3/netlist.txt ../output/output3.txt

../bin/legalizer ../public_cases/testcase2/architecture.txt ../public_cases/testcase2/instance.txt ../public_cases/testcase2/netlist.txt ../output/output2.txt

../bin/legalizer ../public_cases/testcase1/architecture.txt ../public_cases/testcase1/instance.txt ../public_cases/testcase1/netlist.txt ../output/output1.txt    

../bin/verifier ../public_cases/testcase1/architecture.txt ../public_cases/testcase1/instance.txt ../public_cases/testcase1/netlist.txt ../output/output1.txt

../bin/legalizer ../public_cases/test/architecture.txt ../public_cases/test/instance.txt ../public_cases/test/netlist.txt ../output/test.txt