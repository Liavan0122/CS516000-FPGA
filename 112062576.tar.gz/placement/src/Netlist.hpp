#ifndef NETLIST_HPP
#define NETLIST_HPP
#include<bits/stdc++.h>
#include "Instance.hpp"

class Instance;

class Netlist{
public:
    std::string net_name;
    std::vector<Instance*> instance_connection;

    Netlist();
    Netlist(std::string name, std::vector<Instance* > ins_vector);
};
#endif //NETLIST_HPP