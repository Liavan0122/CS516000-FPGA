#ifndef INSTANCE_HPP
#define INSTANCE_HPP
#include<bits/stdc++.h>

class Instance{
public:
    std::string instance_name;
    std::string instance_type;
    float x_coordinate, y_coordinate;
    bool movable;                       // 1 for movable, 0 for can't move

    Instance();
    Instance(std::string name, std::string type, float x, float y, bool m);
};

#endif // INSTANCE_HPP