#include "Netlist.hpp"

Netlist::Netlist() : net_name(""), instance_connection({}) {}

Netlist::Netlist(std::string name, std::vector<Instance*> ins_vector) : net_name(name), instance_connection(ins_vector) {}

