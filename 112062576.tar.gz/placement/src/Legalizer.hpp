#include <bits/stdc++.h>
#include "Resource.hpp"
#include "Instance.hpp"
#include "Netlist.hpp"

/*
#ifndef RESOURCE_HPP
#define RESOUCE_HPP
#include "Resource.hpp"
#endif

#ifndef INSTANCE_HPP
#define INSTANCE_HPP
#include "Instance.hpp"
#endif

#ifndef NETLIST_HPP
#define NETLIST_HPP
#include "Netlist.hpp"
#endif
*/
class Legalizer{
public:
    // Main data structures
    std::unordered_map <std::string, Resource> resource_list;
    std::unordered_map <std::string, Instance> instance_list;
    std::unordered_map <std::string, Netlist> net_list;
    double HPWL_after_prototyping, HPWL_Best;

    // Time variables
    clock_t startAll;


    std::unordered_map<std::string, Instance> originalInstanceList;
    std::unordered_map<std::string, Resource> originalResourceList;
    std::unordered_map<std::string, Instance> bestInstanceList;
    std::unordered_map<std::string, Resource> bestResourceList;




    Legalizer();
    Legalizer(const std::string& filepath_arch, const std::string &filepath_ins, const std::string &filepath_net, const std::string &outputpath);

    // Read File
    void readfile(const std::string &filepath_arch, const std::string &filepath_ins, const std::string &filepath_net);
    void readfile_arch(const std::string& filepath_arch);
    void readfile_ins(const std::string& filepath_ins);
    void readfile_net(const std::string& filepath_net);
    void print();

    void placement_prototyping();
    void placement_prototyping_v2();

    float euclideanDistance(const Instance& a,const Resource& b);

    //void detailed_placement();
    void simulatedAnnealing();
    void perturbSwap();
    void perturbMoving();


    double calculateHPWL();
    double calculateNetlistLengthForInstances();
    //void print_time_info();
    void result(const std::string &outputpath);



};
