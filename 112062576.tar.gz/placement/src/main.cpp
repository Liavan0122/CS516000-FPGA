#include "Legalizer.hpp"

#include<bits/stdc++.h>

int main(int argc, char* argv[]) {

    if (argc != 5) {
            std::cerr << "Invalid input" << std::endl;
            return 1;
        }
    Legalizer legalizer(argv[1], argv[2], argv[3], argv[4]);

	return 0;
}