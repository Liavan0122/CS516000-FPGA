#include "Legalizer.hpp"

Legalizer::Legalizer(){};
Legalizer::Legalizer(const std::string& filepath_arch, const std::string &filepath_ins, const std::string &filepath_net, const std::string &outputpath){
    startAll = clock();

    std::cout << "Reading files ---------" << std::endl;
    readfile(filepath_arch, filepath_ins, filepath_net);


    std::cout << "Placement prototyping ---------" << std::endl;
    placement_prototyping();
    //placement_prototyping_v2();

    HPWL_after_prototyping = calculateHPWL();
    std::cout << "Initial HPWL : " << HPWL_after_prototyping << std::endl;

    std::cout << "Simulated Annealing ---------" << std::endl;
    simulatedAnnealing();

    //std::cout << "Detailed Placing ---------" << std::endl;
    //detailed_placement();

    // Final Instances & Resource print
    //print();
    std::cout << "Final HPWL : " << HPWL_Best << std::endl;

    std::cout << "Outputing ---------" << std::endl;
    result(outputpath);

}
void Legalizer::readfile(const std::string &filepath_arch, const std::string &filepath_ins, const std::string &filepath_net){
    //startInput = clock();
    readfile_arch(filepath_arch);
    readfile_ins(filepath_ins);
    readfile_net(filepath_net);
    //timeInput = (double)(clock() - startInput)/CLOCKS_PER_SEC;

    //print();
}
void Legalizer::readfile_arch(const std::string &filepath_arch){
    std::ifstream inf(filepath_arch);
	std::string line;
    while(std::getline(inf, line)){
        std::stringstream ss(line);
        std::string name, type;
        float x,y;
        ss >> name >> type >> x >> y;
        Resource resource_temp(name, type ,x, y, 0);
        resource_list[name] = resource_temp;
    }
}
void Legalizer::readfile_ins(const std::string &filepath_ins){
    std::ifstream inf(filepath_ins);
	std::string line;
    Instance instance_temp;

    while(std::getline(inf, line)){
        std::stringstream ss(line);
        std::string name, type;
        float x,y;
        ss >> name >> type >> x >> y;

        if(type == "IO"){
            instance_temp = Instance(name, type ,x, y, 0);
        }
        else{
            instance_temp = Instance(name, type ,x, y, 1);
        }
        instance_list[name] = instance_temp;
    }

}
void Legalizer::readfile_net(const std::string &filepath_net){

    std::ifstream inf(filepath_net);
    std::string line;


    while(std::getline(inf, line)) {
        std::stringstream ss(line);
        std::vector<Instance* > netinstance;
        std::string netname, instancename;
        ss >> netname;
        while (ss >> instancename) {
            auto it = instance_list.find(instancename);
            if (it != instance_list.end()) {
                netinstance.push_back(&(it->second));
            }
        }
        Netlist net(netname, netinstance);
        net_list[netname] = net;

    }
}
void Legalizer::print(){
    // Resources read print
    std::cout << "-----------------------------" << std::endl;
    std::cout << "[Resource :]\n" << std::endl;
    for (const auto& pair : resource_list) {
        const Resource& resource = pair.second;
        std::cout << "\nName: " << resource.resource_name << "\nType: " << resource.resource_type
                  << "\nX: " << resource.x_coordinate << "\nY: " << resource.y_coordinate << "\nOccupied: " << resource.occupied << std::endl;
    }
    std::cout << std::endl;

    // Instances read print
    std::cout << "-----------------------------" << std::endl;
    std::cout << "[Instance :]\n" << std::endl;
    for (const auto& pair : instance_list) {
        const Instance& ins = pair.second;
        std::cout << "\nName: " << ins.instance_name << "\nType: " << ins.instance_type
                  << "\nX: " << ins.x_coordinate << "\nY: " << ins.y_coordinate << "\nMovabble: " << ins.movable << std::endl;
    }
    std::cout << std::endl;
/*
    // netlists read print
    std::cout << "-----------------------------" << std::endl;
    std::cout << "[netlist :]\n" << std::endl;
    for (const auto& pair : net_list) {
        const Netlist& net = pair.second;
        std::cout << "\nNet Name: " << net.net_name << "\nConnections: ";
        for (const auto instance : net.instance_connection) {
            std::cout << instance->instance_name << " ";
        }
    }
    std::cout << std::endl;
*/
}

void Legalizer::placement_prototyping() {
    std::unordered_map<std::string, std::vector<Resource*>> classifiedResources;
    for (auto& resour : resource_list) {
        Resource* res = &resour.second;
        classifiedResources[res->resource_type].push_back(res);
    }
    std::unordered_map<std::string, std::vector<Instance*>> classifiedInstances;
    for (auto& instan : instance_list) {
        Instance* ins = &(instan.second);
        if (ins->movable) {
            classifiedInstances[ins->instance_type].push_back(ins);
        }
    }
    for (auto& typeInstances : classifiedInstances) {
        std::string instanceType = typeInstances.first;
        if (instanceType == "IO") {
            continue;
        }

        if (classifiedResources.find(instanceType) != classifiedResources.end()) {
            for (Instance* ins : typeInstances.second) {
                Resource* closestResource = nullptr;
                float minDistance = FLT_MAX;
                float currentDistance = 0.0;

                for (Resource* res : classifiedResources[instanceType]) {
                    if (!res->occupied) {
                        currentDistance = euclideanDistance(*ins, *res);
                        if (currentDistance < minDistance) {
                            minDistance = currentDistance;
                            closestResource = res;
                        }
                    }
                }
                if (closestResource != nullptr) {
                    ins->x_coordinate = closestResource->x_coordinate;
                    ins->y_coordinate = closestResource->y_coordinate;
                    closestResource->occupied = 1;
                }
            }
        }
    }
}

void Legalizer::placement_prototyping_v2(){

    for(auto& instan: instance_list){
        Instance* ins = &(instan.second);
        Resource* closestResource = nullptr;

        float minDistance = FLT_MAX;
        float currentDistance = 0.0;

        if(ins->movable){
            for(auto& resour:resource_list){
                Resource* res = &resour.second;
                if(ins->instance_type == res->resource_type && !res->occupied){
                    currentDistance = euclideanDistance(*ins,*res);
                    if(currentDistance < minDistance){
                        minDistance = currentDistance;
                        closestResource = res;
                    }

                }
            }
            if(closestResource != nullptr){
                ins->x_coordinate = closestResource->x_coordinate;
                ins->y_coordinate = closestResource->y_coordinate;
                closestResource->occupied = 1 ;
            }
        }
        else
            continue;
    }
}

float Legalizer::euclideanDistance(const Instance& a,const Resource& b){
    return std::sqrt(std::pow(a.x_coordinate - b.x_coordinate, 2) + std::pow(a.y_coordinate - b.y_coordinate, 2));
    /*return std::abs(a.x_coordinate-b.x_coordinate)+std::abs(a.y_coordinate-b.y_coordinate);*/
}
/*
void Legalizer::detailed_placement(){
    // Sort first by x, y coordinate

    std::vector<Instance> sort_instances;
    for(const auto& pair : instance_list){
        sort_instances.push_back(pair.second);
    }
    std::sort(sort_instances.begin(),sort_instances.end(), [](const Instance& a, const Instance&b){
        return std::tie(a.x_coordinate, a.y_coordinate) < std::tie(b.x_coordinate,b.y_coordinate);
    });
    //std::cout << "--------After Sort !---------" << std::endl;


    instance_list.clear();
    for(const auto& inst : sort_instances){
        instance_list[inst.instance_name] = inst;
    }

    // for(const auto& inst : sort_instances){
    //     std::cout << "Name: " << inst.instance_name << ", Type: " << inst.instance_type
    //     << ", X: " << inst.x_coordinate << ", Y: " << inst.y_coordinate
    //     << ", Movable: " << (inst.movable ? "true" : "false") << std::endl;
    // }


    //---------------------------------------------------//
    // Swap y neighborhood for calculate cost, namely, "Local moving".
    originalInstanceList = instance_list;
    HPWL_after_prototyping = HPWL_Best;

    for(auto it = instance_list.begin(); std::next(it) != instance_list.end(); std::advance(it, 1)){
        // std::cout << "交換前: \n" << it->second.x_coordinate << " " << it->second.y_coordinate << std::endl;
        // std::cout <<  std::next(it)->second.x_coordinate << " " << std::next(it)->second.y_coordinate << std::endl;

        std::swap(it->second.x_coordinate, std::next(it)->second.x_coordinate);
        std::swap(it->second.y_coordinate, std::next(it)->second.y_coordinate);


        // std::cout << "交換後: \n" << it->second.x_coordinate << " " << it->second.y_coordinate << std::endl;
        // std::cout <<  std::next(it)->second.x_coordinate << " " << std::next(it)->second.y_coordinate << std::endl;

        double newHPWL = calculateHPWL();

        if(newHPWL >= HPWL_after_prototyping){
            //std::cout << "not : " << std::endl;
            instance_list = originalInstanceList;
        }
        else{
            //std::cout << "yes : " << std::endl;
            originalInstanceList = instance_list;
            HPWL_after_prototyping = newHPWL;
        }
        //std::cout << "HPWL : " << HPWL_after_prototyping << std::endl;
    }
}
*/
void Legalizer::simulatedAnnealing(){
    // Parameters setting
    double initialTemperature = 100.0, temperatureMin = 5;
    double coolingRate = 0.95, rejectRatio = 0.95;
    double temperature = initialTemperature;
    int iteration = instance_list.size() * 100;


    // Time limit
    double timeLimit = 500.0;

    // Variables
    int generationCount = 2, rejectCount = 1;
    //int uphillCount = 0;
    bool terminal = false;

    // Copy
    originalInstanceList = instance_list;
    originalResourceList = resource_list;
    bestInstanceList = instance_list;
    bestResourceList = resource_list;
    HPWL_Best = HPWL_after_prototyping;

    while (temperature >= temperatureMin && ((double)rejectCount / (double)generationCount) <= rejectRatio) {
        generationCount = 0, rejectCount = 0;
        //uphillCount = 0;

        while(generationCount <= iteration){

            // Check the elapsed time
            clock_t current_time = clock();
            double elapsed_seconds = (double)(current_time - startAll) / CLOCKS_PER_SEC;
            //std::cout << "Elapsed time so far: " << elapsed_seconds << " seconds" << std::endl;

            if (elapsed_seconds > timeLimit) {
                terminal = true;
                break;
            }
            // Perturb
            int swap_or_move = std::rand()%2;
            if (swap_or_move == 0) {
                perturbSwap();
            }
            else {
                perturbMoving();
            }
            //std::cout << "[Im fine] " << std::endl;

            generationCount++;
            double newHPWL = calculateHPWL();
            double costDifference = newHPWL - HPWL_after_prototyping;
            /*
            if (costDifference < 0 || std::exp(-costDifference / temperature) > (std::rand() % 1000) / 1000.0) {
                if(costDifference < 0)
                {
                    //std::cout << "[Accept]"  << std::endl;
                    //std::cout << "[newHPWL : ]"  <<  newHPWL << std::endl;
                    if(newHPWL < HPWL_Best){
                        HPWL_Best = newHPWL;
                        bestInstanceList = instance_list;
                        bestResourceList = resource_list;
                    }
                    HPWL_after_prototyping = newHPWL;
                    originalInstanceList = instance_list;
                    originalResourceList = resource_list;

                }
                else{
                    //std::cout << "[Worst but accept]"  << std::endl;
                    HPWL_after_prototyping = newHPWL;
                    originalInstanceList = instance_list;
                    originalResourceList = resource_list;
                    uphillCount++;
                }
            }
            else {
                //std::cout << "[Not accept]"  << std::endl;
                instance_list = originalInstanceList;
                resource_list = originalResourceList;
                rejectCount++;
            }*/
            if (costDifference < 0) {
                    HPWL_Best = newHPWL;
                    bestInstanceList = instance_list;
                    bestResourceList = resource_list;
                    HPWL_after_prototyping = newHPWL;
                    originalInstanceList = instance_list;
                    originalResourceList = resource_list;
            }
            else {
                //std::cout << "[Not accept]"  << std::endl;
                instance_list = originalInstanceList;
                resource_list = originalResourceList;
                rejectCount++;
            }
        }

        // VPR

        double alpha = temperature/initialTemperature;

        if(alpha > 0.95 )
            coolingRate = 0.5;
        else if(alpha <= 0.95 && alpha > 0.8)
            coolingRate = 0.9;
        else if(alpha <= 0.8 && alpha > 0.15)
            coolingRate = 0.95;
        else if(alpha <= 0.15)
            coolingRate = 0.8;

        temperature *= coolingRate;
        //std::cout << "temperature so far: " <<  temperature << std::endl;

        if (terminal) {
            break;
        }
    }
    instance_list = bestInstanceList;
    resource_list = bestResourceList;
}

void Legalizer::perturbSwap(){
    //std::cout << "[Im fine2] " << std::endl;
    int index1, index2;
    int size = instance_list.size();
    auto instance1 = instance_list.begin();
    auto instance2 = instance_list.begin();
    do{
        instance1 = instance_list.begin();
        instance2 = instance_list.begin();
        index1 = std::rand() % size;
        index2 = std::rand() % size;

        std::advance(instance1, index1);
        std::advance(instance2, index2);

    }while(index1 == index2 || instance1->second.instance_type != "CLB" || instance2->second.instance_type != "CLB");


    // std::cout << "Before Swap:" << std::endl;
    // std::cout << "Instance 1: " << instance1->second.instance_name << " (" << instance1->second.x_coordinate << ", " << instance1->second.y_coordinate << ")" << std::endl;
    // std::cout << "Instance 2: " << instance2->second.instance_name << " (" << instance2->second.x_coordinate << ", " << instance2->second.y_coordinate << ")" << std::endl;

    std::swap(instance1->second.x_coordinate, instance2->second.x_coordinate);
    std::swap(instance1->second.y_coordinate, instance2->second.y_coordinate);

    // std::cout << "After Swap:" << std::endl;
    // std::cout << "Instance 1: " << instance1->second.instance_name << " (" << instance1->second.x_coordinate << ", " << instance1->second.y_coordinate << ")" << std::endl;
    // std::cout << "Instance 2: " << instance2->second.instance_name << " (" << instance2->second.x_coordinate << ", " << instance2->second.y_coordinate << ")" << std::endl;
}


void Legalizer::perturbMoving(){

    // Collect empty CLB resources
    int size = instance_list.size();
    std::vector<Resource*> emptyCLBResources;
    for (auto& pair : resource_list) {
        Resource& r = pair.second;
        if (r.resource_type == "CLB" && !r.occupied) {
            emptyCLBResources.push_back(&r);
        }
    }

    // Select a random CLB instance
    auto instance1 = instance_list.begin();
    do{
        instance1 = instance_list.begin();
        std::advance(instance1, std::rand() % size);
    }while(instance1->second.instance_type != "CLB");
    //std::cout << "[Im fine4] " << std::endl;


    Instance& selectedInstance = instance1->second;

        // Store the original position
    float originalX = selectedInstance.x_coordinate;
    float originalY = selectedInstance.y_coordinate;


    // Select a random empty CLB resource
    if (!emptyCLBResources.empty()) {
        int randomIndex = std::rand() % emptyCLBResources.size();
        Resource* selectedResource = emptyCLBResources[randomIndex];

        //Output information before moving
        // std::cout << "Before Moving:" << std::endl;
        // std::cout << "Instance: " << selectedInstance.instance_name
        //           << " (" << selectedInstance.x_coordinate << ", " << selectedInstance.y_coordinate << ")" << std::endl;
        // std::cout << "Empty Resource: " << selectedResource->resource_name
        //           << " (" << selectedResource->x_coordinate << ", " << selectedResource->y_coordinate << ")" << std::endl;

        // Set the original position's resource to empty
        for (auto& pair : resource_list) {
            Resource& r = pair.second;
            if (r.x_coordinate == originalX && r.y_coordinate == originalY) {
                r.occupied = false;
                break;
            }
        }


        // Move the instance to the empty resource
        selectedInstance.x_coordinate = selectedResource->x_coordinate;
        selectedInstance.y_coordinate = selectedResource->y_coordinate;
        selectedResource->occupied = true;

        //Output information after moving
        // std::cout << "After Moving:" << std::endl;
        // std::cout << "Instance: " << selectedInstance.instance_name
        //           << " (" << selectedInstance.x_coordinate << ", " << selectedInstance.y_coordinate << ")" << std::endl;
    }
}
double Legalizer::calculateHPWL(){
    double totalHPWL = 0.0;
    for(const auto& entry: net_list){
        const Netlist& net = entry.second;

        if(net.instance_connection.size()>1){
            float minX = FLT_MAX;
            float minY = FLT_MAX;
            float maxX = 0.0;
            float maxY = 0.0;

            for(const auto& inst: net.instance_connection){
                minX = std::min(minX, inst->x_coordinate);
                minY = std::min(minY, inst->y_coordinate);
                maxX = std::max(maxX, inst->x_coordinate);
                maxY = std::max(maxY, inst->y_coordinate);
            }

            double current_netHPWL = double(maxX - minX + maxY - minY);
            //std::cout << "[" << entry.second.net_name << "] Current net HPWL: " << current_netHPWL << std::endl;
            totalHPWL += current_netHPWL;
        }
    }
    return totalHPWL;
}
/*
void Legalizer::print_time_info(){
    timeTotal = (double)(clock() - startAll)/CLOCKS_PER_SEC;

    std::cout << std::endl;
    std::cout << "-------------------------" << std::endl;
    //std::cout << "[Input time] " << timeInput << " secs" << std::endl;
    //std::cout << "[Prototyping time] " << timePrototyping << " secs" << std::endl;
    std::cout << "[Total time] " << timeTotal << " secs" << std::endl;
    std::cout << "-------------------------" << std::endl;
    std::cout << std::endl;
}*/
void Legalizer::result(const std::string &outputpath){
    std::ofstream fout;
    fout.open(outputpath);

    for (const auto& pair : instance_list) {
        const Instance& ins = pair.second;
        if(ins.instance_type == "IO"){
            continue;
        }
        for(const auto& pair2 : resource_list){
            const Resource& res = pair2.second;
            if(ins.x_coordinate == res.x_coordinate && ins.y_coordinate == res.y_coordinate){
                fout << ins.instance_name << " " << res.resource_name << std::endl;
            }
        }
    }
    //fout << "\nFinal HPWL : " << HPWL_after_prototyping << std::endl;
    fout.close();
}
