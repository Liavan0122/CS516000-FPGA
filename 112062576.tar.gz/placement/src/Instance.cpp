#include "Instance.hpp"

Instance::Instance(){
    this->instance_name = "";
    this->instance_type = "";
    this->x_coordinate = 0.0f;
    this->y_coordinate = 0.0f;
    this->movable = 0;
}

Instance::Instance(std::string name, std::string type, float x, float y, bool m){
    this->instance_name = name;
    this->instance_type = type;
    this->x_coordinate = x;
    this->y_coordinate = y;
    this->movable = m;
}